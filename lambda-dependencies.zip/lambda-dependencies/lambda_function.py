import json
import mysql.connector

def lambda_handler(event, context):
    # TODO implement
    mydb = mysql.connector.connect(
         host="database-1.c2fgqwg963dz.us-east-1.rds.amazonaws.com",
         user="admin",
         password="Administrator",
         database="database-1"
    )
    
    mycursor = mydb.cursor()

    mycursor.execute("CREATE TABLE customers (name VARCHAR(255), address VARCHAR(255))")
    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
